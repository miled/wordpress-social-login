see https://github.com/hybridauth/hybridauth/releases
